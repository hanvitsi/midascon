/** Automatically generated file. DO NOT MODIFY */
package midascon.example.emergency;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}